import cv2
from ultralytics import YOLO
import numpy as np
import pandas as pd 

model = YOLO('D:/python/license/pt models/best (4).pt')
cap = cv2.VideoCapture("D:/python/license/test videos/movie1.mov")
counter = 1
lmlist = []

while True:
    success, frame = cap.read()
    frame = cv2.resize(frame,(720,720))
    results = model.predict(frame,imgsz=640, verbose = False)
    ann = results[0].plot()
    for result in results:
        boxes = result.boxes.cpu().numpy()
        for box in boxes:
            #print(result.names[int(box.cls[0])])
            if result.names[int(box.cls[0])] == "No Helmet":
                #print('TRUE')
                filename = 'D:/python/license/raw_data/' +str(counter) + ".jpg"
                cv2.imwrite(filename,ann)
                counter +=1
                
         
    # for i in results[0].boxes.xyxy:
    #     loc = i[0],i[1],i[2],i[3]
    #     print(results.names[int(i.cls[0])])
    #     lmlist.append(loc)
    #     index = pd.MultiIndex.from_tuples(lmlist, names=["X1", "Y1","X2","Y2"])
    #     data = list(zip(*lmlist))
    #     X1, Y1,X2,Y2 = pd.Series(data[0]), pd.Series(data[1]), pd.Series(data[2]),pd.Series(data[3])
    #     df = pd.DataFrame({'X1' : X1, 'Y1': Y1, 'X2': X2, 'Y2':Y2})
    # df.to_csv('live.csv')
    cv2.imshow("Video", ann)
    if cv2.waitKey(1) == 13:
        break
cap.release()
